/**
 * @returns {Promise}
 */
export async function mainMacros(data, slot) {
  if ( !data.roll || !data.label ) return false;
  //to implement..
  return false;
}
