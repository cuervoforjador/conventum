/**
 * Helpers for Sprites
 */

import { mainUtils } from "../mainUtils.js";

export class helperSprites {

}