/**
 * @extends {Item}
 */
export class extendItem extends Item {

  /**
   * Derivatives and other data...
   * @inheritdoc
   */
  prepareDerivedData() {
    super.prepareDerivedData();
  }

}
