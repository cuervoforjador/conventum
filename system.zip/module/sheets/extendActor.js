/**
 * @extends {Actor}
 */
export class extendActor extends Actor {

  /**
   * Derivatives and other data...
   * @inheritdoc
   */
  prepareDerivedData() {
    super.prepareDerivedData();
  }

  /**
   * Data for rolling...
   * @inheritdoc
   * @returns {object}
   */
  
  /**
  getRollData() {
    const data = this.toObject(false);
    // to implement...
    return data;
  }
   */

}
